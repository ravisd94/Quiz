﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;

namespace ExamPanel
{
    public partial class Test : System.Web.UI.Page
    {
        public int i=0;
        DataTable dt = new DataTable();
        DataRow dr;
        SqlCommand cmd;
        
        

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["EmailID"] != null)
            {
                if(!IsPostBack)
                {
                    lbl_Welcome.Text = "Welcome "+ Session["EmailID"].ToString();
                    GetQuestions(); 
                }
            }
            else 
            {
                Response.Redirect("StartTheTest.aspx");
            }
        }
        protected void GetQuestions()
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ExamCS"].ConnectionString))
            {
                dt.Rows.Clear();
                cmd = new SqlCommand("SP_StartTheTest", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@user_Email_id", Session["EmailID"].ToString());
                con.Open();
                SqlDataAdapter da= new SqlDataAdapter(cmd);
                da.Fill(dt);
                ViewState["DataTable"] = dt;
                if (dt.Rows.Count > 0)
                {
                    dr = dt.Rows[i];
                    int SrNo = 11 - dt.Rows.Count;
                    lbl_Question.Text = SrNo + ". " + dr["Question"].ToString();
                    RadioButtonList1.Items.Add(new ListItem(dr["Option1"].ToString(), "1"));
                    RadioButtonList1.Items.Add(new ListItem(dr["Option2"].ToString(), "2"));
                    RadioButtonList1.Items.Add(new ListItem(dr["Option3"].ToString(), "3"));
                    RadioButtonList1.Items.Add(new ListItem(dr["Option4"].ToString(), "4"));
                    if (SrNo == 10)
                    {
                        btn_Next.Text = "Submit";
                    }
                }
                else
                {
                    Response.Redirect("FinalResult.aspx");
                }
                    
            }
        }

        protected void btn_Next_Click(object sender, EventArgs e)
        {
            SaveDatainAM();
            RadioButtonList1.Items.Clear();
            GetQuestions();
            
        }
        protected void SaveDatainAM()
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ExamCS"].ConnectionString))
            {
                dt = (DataTable)ViewState["DataTable"];
                dr = dt.Rows[i];
                cmd = new SqlCommand("SP_Add_Attempt_Master", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@user_Email_id", Session["EmailID"].ToString());
                cmd.Parameters.AddWithValue("@Qustion_id", dr["Question_ID"].ToString());
                cmd.Parameters.AddWithValue("@answer", RadioButtonList1.SelectedValue);
                con.Open();
                cmd.ExecuteNonQuery();

            }
            }

        protected void btn_SignOut_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("StartTheTest.aspx");
        }
    }
}