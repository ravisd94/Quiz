﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ExamPanel
{
    public partial class StartTheTest : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_Start_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                Session["EmailID"] = txt_EmailID.Text;
                Response.Redirect("Test.aspx");
            }
        }
    }
}