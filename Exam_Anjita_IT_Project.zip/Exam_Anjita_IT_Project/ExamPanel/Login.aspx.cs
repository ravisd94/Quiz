﻿using System;
using System.Web.Security;

namespace ExamPanel
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if(txt_Email.Text.ToLower()=="admin" && txt_Password.Text=="admin123")
            {
                Session["adminUser"] = txt_Email.Text;
                Response.Redirect("CreateTest.aspx");
            }
            else
            { lbl_msg.Text = "Invalid User Name or password"; }
              
           
        }
    }
}