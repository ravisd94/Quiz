﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
namespace ExamPanel
{
    public partial class CreateTest : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["adminUser"]==null)
            {
                Response.Redirect("Login.aspx");
            }
            else
            {
                if (!IsPostBack)
                { GetDataGV(); }
            } 

        }

        protected void btn_submit_Click(object sender, EventArgs e)
        {
            Save_Data();
        }
        protected void Save_Data()
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ExamCS"].ConnectionString))
            {

                SqlCommand cmd = new SqlCommand("sp_Insert_Exam", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Question", txt_Question.Text);
                cmd.Parameters.AddWithValue("@Option1", txt_Ans1.Text);
                cmd.Parameters.AddWithValue("@Option2", txt_Ans2.Text);
                cmd.Parameters.AddWithValue("@Option3", txt_Ans3.Text);
                cmd.Parameters.AddWithValue("@Option4", txt_Ans4.Text);
                cmd.Parameters.AddWithValue("@Answer", RadioButtonList1.SelectedValue);
                try
                {
                    con.Open();
                    int returnValue = Convert.ToInt32(cmd.ExecuteScalar());
                    if (returnValue == 1)
                    {
                        lbl_Msg.ForeColor = Color.Green;
                        lbl_Msg.Text = "Data Saved Successfully";
                    }
                    else
                    {
                        lbl_Msg.ForeColor = Color.Red;
                        lbl_Msg.Text = "You can save only 10 questions.";
                    }
                    GetDataGV();
                }
                catch (Exception ex)
                {
                    lbl_Msg.ForeColor = Color.Red;
                    lbl_Msg.Text = "Error! Data not saved";
                }

            }

        }
        protected void btn_Clear_Click(object sender, EventArgs e)
        {
            RequiredFieldValidator1.ErrorMessage = string.Empty;
            txt_Question.Text = string.Empty;
            txt_Ans1.Text = string.Empty;
            txt_Ans2.Text = string.Empty;
            txt_Ans3.Text = string.Empty;
            txt_Ans4.Text = string.Empty;
            lbl_Msg.Text = string.Empty;
        }
        protected void Bind_Grid(DataSet ds)
        {
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }
        protected void GetDataGV()
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ExamCS"].ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("select ROW_NUMBER() over (order by (select 1)) as sno, Question_ID,Question,Option1,Option2,Option3,Option4,Answer from exam_test_master", con);
                cmd.CommandType = CommandType.Text;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                con.Open();
                cmd.ExecuteNonQuery();
                da.Fill(ds);
                Bind_Grid(ds);
            }
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            GetDataGV();
        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            GetDataGV();
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ExamCS"].ConnectionString))
            {
                //string QID = ((Label)GridView1.Rows[e.RowIndex].FindControl("lbl_Question_ID ")).Text;
                Label Qid = GridView1.Rows[e.RowIndex].FindControl("lbl_Question_ID") as Label;
                TextBox Question = GridView1.Rows[e.RowIndex].FindControl("txt_Question") as TextBox;
                TextBox Option1 = GridView1.Rows[e.RowIndex].FindControl("txt_Option1") as TextBox;
                TextBox Option2 = GridView1.Rows[e.RowIndex].FindControl("txt_Option2") as TextBox;
                TextBox Option3 = GridView1.Rows[e.RowIndex].FindControl("txt_Option3") as TextBox;
                TextBox Option4 = GridView1.Rows[e.RowIndex].FindControl("txt_Option4") as TextBox;
                TextBox Answer = GridView1.Rows[e.RowIndex].FindControl("txt_Answer") as TextBox;

                SqlCommand cmd = new SqlCommand("SP_Update_Exam_master", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Question_ID", Qid.Text);
                cmd.Parameters.AddWithValue("@Question", Question.Text);
                cmd.Parameters.AddWithValue("@Option1", Option1.Text);
                cmd.Parameters.AddWithValue("@Option2", Option2.Text);
                cmd.Parameters.AddWithValue("@Option3", Option3.Text);
                cmd.Parameters.AddWithValue("@Option4", Option4.Text);
                cmd.Parameters.AddWithValue("@Answer", Answer.Text);
                con.Open();
                cmd.ExecuteNonQuery();

                GridView1.EditIndex = -1;
                GetDataGV();
            }
        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {   
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ExamCS"].ConnectionString))
            {
                Label Qid = GridView1.Rows[e.RowIndex].FindControl("lbl_Question_ID") as Label;
                SqlCommand cmd = new SqlCommand("SP_Delete_ExamTest", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Question_ID", Qid.Text);
                con.Open();
                cmd.ExecuteNonQuery();
                GridView1.EditIndex = -1;
                GetDataGV();
            }
        }
    }
    }
