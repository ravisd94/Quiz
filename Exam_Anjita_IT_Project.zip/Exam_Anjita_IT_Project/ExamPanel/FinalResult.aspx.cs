﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace ExamPanel
{
    public partial class FinalResult : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["EmailID"] != null)
            {
                if (!IsPostBack)
                {
                    GetResult();
                }
            }
            else
            {
                Response.Redirect("StartTheTest.aspx");
            }
        }
        protected void GetResult()
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ExamCS"].ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("TotalMarks", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@user_Email_id", Session["EmailID"].ToString());
                con.Open();
                int ReturnValue=Convert.ToInt32(cmd.ExecuteScalar());
                if (ReturnValue == 0)
                {
                    Response.Redirect("Test.aspx");
                }
                else 
                {
                    lbl_msg.Text = "You have completed the Test and your Total Score: " + ReturnValue;
                }
            }
        }
        protected void btn_SignOut_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("StartTheTest.aspx");
        }
    }
}